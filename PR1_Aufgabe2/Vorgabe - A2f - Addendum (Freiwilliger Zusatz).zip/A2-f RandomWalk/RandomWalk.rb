require 'tk'
require 'Rechteck'
require 'Einstellungen'
require "Trace"

class RandomWalk
  def initialize()
    @offset = Point.new(10,10)
    @leinwand = Leinwand.gib_einzige_instanz()
  end

  
  def random_walk(n)
    
    @leinwand.clear()
    spielfeld_zeichnen(n)

    shape = [n,n]   
    spur = Trace.new(@leinwand,shape,5)

    # TODO hier den RandomWalk implementieren
    # dabei die Koordinaten der spur hinzufügen


        
    # spur anzeigen
    spur.show()
  end

  
  def spielfeld_zeichnen(n)
    # erzeugt ein Rechteck ohne Füllung
    # dient der visuellen Kontrolle für die Berechnungen
    grenze = Rechteck.new(@offset,2*n,2*n,:black,false)
    grenze.sichtbar_machen()
  end

end

