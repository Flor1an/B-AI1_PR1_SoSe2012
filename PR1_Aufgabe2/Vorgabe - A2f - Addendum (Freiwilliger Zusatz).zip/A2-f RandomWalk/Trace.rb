require "tk"

class Trace 
  
  def initialize(canvas,shape,skip=10)
    @canvas = canvas
    @shape = shape
    @poly = TkcPolygon.new(canvas,shape)
    @poly[:outline] = :red 
    @poly[:fill] = :white
    @skip = skip
    @steps = 0
  end

  def add(x,y)
   @steps +=1
   if (@steps % @skip == 0)
     @shape << x
     @shape << y
   end   
  end
  
  def show()
    @poly.coords(@shape)
  end
end