require 'tk'
require 'Rechteck'
require 'Kreis'
require 'Dreieck'
require 'Einstellungen'

class Zeichnung
     
  def initialize()
    # Wir benutzen die geometrischen Figuren, um ein Haus zu konstruieren
    
    # Das Szenario spielt sich am Tag ab, die Sonne scheint
  end
  
end

