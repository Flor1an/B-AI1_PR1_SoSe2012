require 'tk'
require 'Rechteck'
require 'Kreis'
require 'Dreieck'
require 'Einstellungen'

class KreaturenParcour
      
  def initialize()
    # Hier die Kreaturen erzeugen und anzeigen
  end
     
end

