
class Life
  @@muster = []
  @@muster[0] = [[1,2],[2,3],[3,1],[3,2],[3,3]]
    
  # weitere Muster unter http://de.wikipedia.org/wiki/Conways_Spiel_des_Lebens
    
  def initialize(n,muster_index)

  end

  def zuruecksetzen()
    # Löscht alle 
    Leinwand.gib_einzige_instanz().zuruecksetzen()
    # TODO Hier sind sie dran
  end

  def simuliere(schritte)
    TkTimer.new(100,schritte, proc{
      #TODO hier die Methode für die schrittweise Simulation aufrufen
      print ""
    }).start(0, proc{})
    puts
  end

end