require "test/unit"
require "Relation"
require "Tupel"
require "Set"
require "RelationenGenerator"
require "Potenzmenge"

class RelationenTest < Test::Unit::TestCase

end