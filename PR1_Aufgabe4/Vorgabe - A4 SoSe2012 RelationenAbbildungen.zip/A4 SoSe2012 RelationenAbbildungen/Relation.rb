require "Potenzmenge"

class Relation

  #TODO
end