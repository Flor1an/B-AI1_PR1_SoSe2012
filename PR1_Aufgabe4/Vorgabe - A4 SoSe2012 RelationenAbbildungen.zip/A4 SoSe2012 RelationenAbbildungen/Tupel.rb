class Tupel
  #TODO
end