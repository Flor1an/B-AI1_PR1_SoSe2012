require "Set"
require "Relation"
require "Tupel"

class RelationenGenerator
  def RelationenGenerator.generiere_relation(set_a,set_b,k)
    #TODO   
  end

  def RelationenGenerator.generiere_abbildung(set_a,set_b)
    #TODO
  end
  
end